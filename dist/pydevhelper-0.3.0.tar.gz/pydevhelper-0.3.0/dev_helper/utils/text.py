import re
import unicodedata
from typing import List


def slugify(text: str, allow_unicode: bool = False) -> str:
    text = str(text)
    if allow_unicode:
        text = unicodedata.normalize("NFKC", text).lower()
        text = re.sub(r"[\s_]+", "-", text)  # espaços/underscores → hífen
        text = re.sub(r"[^\w\-]+", "", text)  # remove tudo menos letras unicode/números/hífens
    else:
        text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
        text = text.lower()
        text = re.sub(r"[\s_]+", "-", text)
        text = re.sub(r"[^a-z0-9-]", "", text)

    # Limpeza final
    text = re.sub(r"-{2,}", "-", text)
    return text.strip("-")


def camel_to_snake(text: str) -> str:
    """Converte CamelCase → snake_case."""
    text = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", text)
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", text)
    return text.lower()


def snake_to_camel(text: str, preserve_acronyms: bool = False) -> str:
    """Converte snake_case → CamelCase."""
    words = text.split("_")
    if preserve_acronyms:
        return "".join(w.upper() if w.isupper() else w.capitalize() for w in words)
    return "".join(w.capitalize() for w in words)


def normalize_whitespace(text: str) -> str:
    """Remove espaços extras e normaliza para um espaço simples."""
    return re.sub(r"\s+", " ", text).strip()


def remove_html_tags(text: str) -> str:
    """Remove tags HTML da string."""
    return re.sub(r"<[^>]+>", "", text)


def extract_emails(text: str) -> List[str]:
    """Extrai todos os emails válidos de um texto."""
    return re.findall(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", text)


def extract_urls(text: str) -> List[str]:
    """Extrai todas as URLs de um texto (inclui paths e queries)."""
    return re.findall(r"https?://[^\s<>\"']+", text)
