# Guia de Contribuição

Obrigado por considerar contribuir com **PyDevHelper**! 🎉

## Como contribuir

1. Faça um fork do repositório.
2. Crie uma branch para sua mudança:
   ```bash
   git checkout -b minha-feature
