# Guia de Contribuição

Obrigado por considerar contribuir com **PyDevHelper**! 🎉

## Como contribuir

Contribuições são bem-vindas\! Sinta-se à vontade para abrir uma *issue* para reportar bugs ou sugerir novas funcionalidades.

1. Faça um fork do repositório.
2. Crie uma branch para sua mudança:
   ```bash
   git checkout -b minha-feature
